package com.infinitygems;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Il guanto: ha sei incastri (uno per gemma).
 *
 * - Clic destro con una gemma o un contenitore nell'altra mano: la incastra.
 * - Clic destro: usa la gemma selezionata.
 * - Maiusc + clic destro: cambia gemma selezionata.
 * - Maiusc + clic destro con una Custodia Vuota nell'altra mano: estrae la gemma selezionata.
 * - Con tutte e 6 le gemme compare la modalita' Schiocco: metà dei mostri vicini svanisce.
 */
public class GauntletItem extends Item {
	private static final String KEY_SOCKETS = "Sockets";
	private static final String KEY_SELECTED = "Selected";

	/** Valore speciale della modalita' selezionata: lo Schiocco. */
	public static final int SNAP = 6;
	public static final int SNAP_COOLDOWN = 1200;

	public GauntletItem(Settings settings) {
		super(settings);
	}

	// ---- Stato salvato nell'oggetto ----

	public static int getSockets(ItemStack stack) {
		NbtCompound nbt = stack.getNbt();
		return nbt == null ? 0 : nbt.getInt(KEY_SOCKETS);
	}

	public static boolean hasStone(ItemStack stack, GemType type) {
		return (getSockets(stack) & (1 << type.ordinal())) != 0;
	}

	private static void setSockets(ItemStack stack, int sockets) {
		stack.getOrCreateNbt().putInt(KEY_SOCKETS, sockets);
	}

	private static void setSelected(ItemStack stack, int mode) {
		stack.getOrCreateNbt().putInt(KEY_SELECTED, mode);
	}

	/** Modalita' tra cui si puo' scegliere: le gemme incastrate, piu' lo Schiocco se ci sono tutte. */
	public static List<Integer> modes(ItemStack stack) {
		List<Integer> list = new ArrayList<>();
		for (GemType type : GemType.values()) {
			if (hasStone(stack, type)) {
				list.add(type.ordinal());
			}
		}
		if (list.size() == GemType.values().length) {
			list.add(SNAP);
		}
		return list;
	}

	/** Modalita' attualmente selezionata, oppure -1 se il guanto e' vuoto. */
	public static int selectedMode(ItemStack stack) {
		List<Integer> modes = modes(stack);
		if (modes.isEmpty()) {
			return -1;
		}
		NbtCompound nbt = stack.getNbt();
		if (nbt != null && nbt.contains(KEY_SELECTED)) {
			int selected = nbt.getInt(KEY_SELECTED);
			if (modes.contains(selected)) {
				return selected;
			}
		}
		return modes.get(0);
	}

	private static Text modeName(int mode) {
		if (mode == SNAP) {
			return Text.translatable("message.infinity_gems.mode_snap");
		}
		return GemType.values()[mode].getDisplayName();
	}

	private static GemType typeOf(ItemStack stack) {
		if (stack.getItem() instanceof GemItem gem) {
			return gem.getType();
		}
		if (stack.getItem() instanceof ContainerItem container) {
			return container.getType();
		}
		return null;
	}

	// ---- Uso ----

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);
		ItemStack other = user.getStackInHand(hand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND);
		boolean client = world.isClient();
		boolean creative = user.getAbilities().creativeMode;

		// 1) Incastra una gemma o un contenitore tenuto nell'altra mano.
		GemType offered = typeOf(other);
		if (offered != null) {
			if (hasStone(stack, offered)) {
				if (!client) {
					user.sendMessage(Text.translatable("message.infinity_gems.already_socketed"), true);
				}
				return TypedActionResult.fail(stack);
			}
			if (!client) {
				boolean wasContainer = other.getItem() instanceof ContainerItem;
				setSockets(stack, getSockets(stack) | (1 << offered.ordinal()));
				setSelected(stack, offered.ordinal());
				if (!creative) {
					other.decrement(1);
					if (wasContainer) {
						user.getInventory().offerOrDrop(new ItemStack(ModItems.EMPTY_CASE));
					}
				}
				world.playSound(null, user.getX(), user.getY(), user.getZ(),
						SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.PLAYERS, 1.0F, 1.2F);
				user.sendMessage(Text.translatable("message.infinity_gems.socketed", offered.getDisplayName()), true);
			}
			return TypedActionResult.success(stack, client);
		}

		// 2) Maiusc: estrai o cambia gemma.
		if (user.isSneaking()) {
			if (other.isOf(ModItems.EMPTY_CASE)) {
				int selected = selectedMode(stack);
				if (selected < 0 || selected == SNAP) {
					if (!client) {
						user.sendMessage(Text.translatable("message.infinity_gems.pick_stone"), true);
					}
					return TypedActionResult.fail(stack);
				}
				if (!client) {
					GemType type = GemType.values()[selected];
					setSockets(stack, getSockets(stack) & ~(1 << selected));
					if (!creative) {
						other.decrement(1);
					}
					user.getInventory().offerOrDrop(new ItemStack(ModItems.CONTAINERS.get(type)));
					user.sendMessage(Text.translatable("message.infinity_gems.ejected", type.getDisplayName()), true);
				}
				return TypedActionResult.success(stack, client);
			}

			List<Integer> modes = modes(stack);
			if (modes.isEmpty()) {
				if (!client) {
					user.sendMessage(Text.translatable("message.infinity_gems.no_gems"), true);
				}
				return TypedActionResult.fail(stack);
			}
			if (!client) {
				int index = modes.indexOf(selectedMode(stack));
				int next = modes.get((index + 1) % modes.size());
				setSelected(stack, next);
				user.sendMessage(Text.translatable("message.infinity_gems.selected", modeName(next)), true);
			}
			return TypedActionResult.success(stack, client);
		}

		// 3) Usa la modalita' selezionata.
		int selected = selectedMode(stack);
		if (selected < 0) {
			if (!client) {
				user.sendMessage(Text.translatable("message.infinity_gems.no_gems"), true);
			}
			return TypedActionResult.fail(stack);
		}

		if (selected == SNAP) {
			ItemCooldownManager cooldowns = user.getItemCooldownManager();
			if (cooldowns.isCoolingDown(this)) {
				return TypedActionResult.fail(stack);
			}
			if (!client && world instanceof ServerWorld serverWorld && user instanceof ServerPlayerEntity serverPlayer) {
				snap(serverWorld, serverPlayer);
			}
			cooldowns.set(this, SNAP_COOLDOWN);
			return TypedActionResult.success(stack, client);
		}

		if (GemType.values()[selected].tryUse(world, user)) {
			return TypedActionResult.success(stack, client);
		}
		return TypedActionResult.fail(stack);
	}

	/** Lo Schiocco: metà dei mostri vicini sparisce. Non tocca giocatori, animali o villager. */
	private static void snap(ServerWorld world, ServerPlayerEntity player) {
		List<HostileEntity> mobs = new ArrayList<>(world.getEntitiesByClass(
				HostileEntity.class,
				player.getBoundingBox().expand(96.0),
				e -> e.isAlive() && e.getType() != EntityType.WITHER));
		Collections.shuffle(mobs);

		int removed = mobs.size() / 2;
		for (int i = 0; i < removed; i++) {
			HostileEntity mob = mobs.get(i);
			world.spawnParticles(ParticleTypes.ASH, mob.getX(), mob.getBodyY(0.5), mob.getZ(), 40, 0.3, 0.5, 0.3, 0.02);
			mob.discard();
		}

		world.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.PLAYERS, 1.0F, 1.0F);
		player.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 600, 1));
		player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 1));
		player.sendMessage(Text.translatable("message.infinity_gems.snap", removed), true);
	}

	@Override
	public boolean hasGlint(ItemStack stack) {
		return getSockets(stack) != 0;
	}

	@Override
	public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
		tooltip.add(Text.translatable("item.infinity_gems.gauntlet.tooltip").formatted(Formatting.GRAY));
		tooltip.add(Text.translatable("item.infinity_gems.gauntlet.tooltip2").formatted(Formatting.DARK_GRAY));
		tooltip.add(Text.translatable("item.infinity_gems.gauntlet.tooltip3").formatted(Formatting.DARK_GRAY));

		for (GemType type : GemType.values()) {
			if (hasStone(stack, type)) {
				tooltip.add(Text.literal("• ").append(type.getDisplayName()).formatted(Formatting.GOLD));
			}
		}
		int selected = selectedMode(stack);
		if (selected >= 0) {
			tooltip.add(Text.translatable("message.infinity_gems.selected", modeName(selected)).formatted(Formatting.AQUA));
		}
	}
}
