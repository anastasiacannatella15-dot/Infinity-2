package com.infinitygems;

import java.util.List;
import net.minecraft.block.CropBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Le sei gemme dell'infinito. Ogni gemma sa cosa fa quando viene usata.
 * L'ordine di questo enum e' importante: l'ordinal() e' usato come bit nel guanto.
 */
public enum GemType {

	SPACE("space_gem", "space_cube", ParticleTypes.PORTAL, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 60) {
		@Override
		protected void apply(ServerWorld world, ServerPlayerEntity player) {
			Vec3d look = player.getRotationVec(1.0F);
			HitResult hit = player.raycast(24.0, 1.0F, false);
			Vec3d eyeTarget = hit.getType() == HitResult.Type.BLOCK
					? hit.getPos().subtract(look.multiply(0.8))
					: player.getEyePos().add(look.multiply(24.0));
			double eyeHeight = player.getEyeY() - player.getY();
			Vec3d feet = new Vec3d(eyeTarget.x, eyeTarget.y - eyeHeight, eyeTarget.z);

			// Se la destinazione e' dentro un blocco, sale fino a trovare spazio libero.
			for (int i = 0; i < 5; i++) {
				Box moved = player.getBoundingBox().offset(
						feet.x - player.getX(), feet.y - player.getY(), feet.z - player.getZ());
				if (world.isSpaceEmpty(player, moved)) {
					break;
				}
				feet = feet.add(0.0, 1.0, 0.0);
			}

			burst(world, ParticleTypes.PORTAL, player.getX(), player.getY() + 1.0, player.getZ());
			player.requestTeleport(feet.x, feet.y, feet.z);
			player.fallDistance = 0.0F;
			burst(world, ParticleTypes.PORTAL, feet.x, feet.y + 1.0, feet.z);
		}
	},

	MIND("mind_gem", "mind_scepter", ParticleTypes.ENCHANT, SoundEvents.BLOCK_BEACON_POWER_SELECT, 100) {
		@Override
		protected void apply(ServerWorld world, ServerPlayerEntity player) {
			for (HostileEntity mob : hostiles(world, player, 18.0)) {
				mob.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 300, 0));
				mob.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 300, 2));
				mob.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 300, 1));
				mob.setTarget(null);
			}
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 300, 0));
		}
	},

	REALITY("reality_gem", "reality_vial", ParticleTypes.CRIT, SoundEvents.ENTITY_EVOKER_PREPARE_SUMMON, 120) {
		@Override
		protected void apply(ServerWorld world, ServerPlayerEntity player) {
			for (HostileEntity mob : hostiles(world, player, 12.0)) {
				if (mob.getType() == EntityType.WITHER) {
					continue;
				}
				burst(world, ParticleTypes.CRIT, mob.getX(), mob.getBodyY(0.5), mob.getZ());
				EntityType.CHICKEN.spawn(world, mob.getBlockPos(), SpawnReason.MOB_SUMMONED);
				mob.discard();
			}
		}
	},

	POWER("power_gem", "power_orb", ParticleTypes.ELECTRIC_SPARK, SoundEvents.BLOCK_BEACON_ACTIVATE, 100) {
		@Override
		protected void apply(ServerWorld world, ServerPlayerEntity player) {
			HitResult hit = player.raycast(40.0, 1.0F, false);
			Vec3d t = hit.getPos();

			LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
			if (bolt != null) {
				bolt.refreshPositionAfterTeleport(t.x, t.y, t.z);
				bolt.setCosmetic(true);
				world.spawnEntity(bolt);
			}

			Box area = new Box(t.x - 5.0, t.y - 3.0, t.z - 5.0, t.x + 5.0, t.y + 5.0, t.z + 5.0);
			List<LivingEntity> targets = world.getEntitiesByClass(
					LivingEntity.class, area, e -> e.isAlive() && e instanceof Monster);
			for (LivingEntity target : targets) {
				target.damage(world.getDamageSources().playerAttack(player), 14.0F);
				target.takeKnockback(0.8, player.getX() - target.getX(), player.getZ() - target.getZ());
			}

			world.spawnParticles(ParticleTypes.EXPLOSION, t.x, t.y, t.z, 6, 1.0, 1.0, 1.0, 0.0);
			world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, t.x, t.y + 0.5, t.z, 50, 1.5, 1.0, 1.5, 0.2);
			world.playSound(null, t.x, t.y, t.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 1.0F);
		}
	},

	TIME("time_gem", "time_amulet", ParticleTypes.GLOW, SoundEvents.BLOCK_AMETHYST_BLOCK_RESONATE, 200) {
		@Override
		protected void apply(ServerWorld world, ServerPlayerEntity player) {
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 400, 2));
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 400, 1));

			for (HostileEntity mob : hostiles(world, player, 14.0)) {
				mob.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 4));
			}

			// Accelera le colture vicine.
			BlockPos c = player.getBlockPos();
			for (BlockPos p : BlockPos.iterate(c.add(-5, -2, -5), c.add(5, 2, 5))) {
				BlockPos pos = p.toImmutable();
				if (world.getBlockState(pos).getBlock() instanceof CropBlock) {
					for (int i = 0; i < 4; i++) {
						world.getBlockState(pos).randomTick(world, pos, world.random);
					}
				}
			}
		}
	},

	SOUL("soul_gem", "soul_chalice", ParticleTypes.SOUL, SoundEvents.PARTICLE_SOUL_ESCAPE, 300) {
		@Override
		protected void apply(ServerWorld world, ServerPlayerEntity player) {
			player.setHealth(player.getMaxHealth());
			player.getHungerManager().add(20, 1.0F);
			player.removeStatusEffect(StatusEffects.POISON);
			player.removeStatusEffect(StatusEffects.WITHER);
			player.removeStatusEffect(StatusEffects.BLINDNESS);
			player.removeStatusEffect(StatusEffects.NAUSEA);
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 1));
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 1200, 2));
		}
	};

	private final String stoneId;
	private final String containerId;
	private final ParticleEffect particle;
	private final SoundEvent sound;
	private final int cooldownTicks;

	GemType(String stoneId, String containerId, ParticleEffect particle, SoundEvent sound, int cooldownTicks) {
		this.stoneId = stoneId;
		this.containerId = containerId;
		this.particle = particle;
		this.sound = sound;
		this.cooldownTicks = cooldownTicks;
	}

	/** Cosa succede quando la gemma viene usata (solo lato server). */
	protected abstract void apply(ServerWorld world, ServerPlayerEntity player);

	public String getStoneId() {
		return stoneId;
	}

	public String getContainerId() {
		return containerId;
	}

	public int getCooldownTicks() {
		return cooldownTicks;
	}

	public Text getDisplayName() {
		return Text.translatable("item.infinity_gems." + stoneId);
	}

	/** Suono, abilita' e particelle. */
	public final void activate(ServerWorld world, ServerPlayerEntity player) {
		world.playSound(null, player.getX(), player.getY(), player.getZ(), sound, SoundCategory.PLAYERS, 1.0F, 1.0F);
		apply(world, player);
		burst(world, particle, player.getX(), player.getY() + 1.0, player.getZ());
	}

	/**
	 * Usa la gemma rispettando il cooldown. Il cooldown e' legato all'oggetto "gemma",
	 * cosi' vale uguale se la usi da sola, dal contenitore o dal guanto.
	 * Restituisce false se e' ancora in ricarica.
	 */
	public boolean tryUse(World world, PlayerEntity player) {
		Item key = ModItems.GEMS.get(this);
		ItemCooldownManager cooldowns = player.getItemCooldownManager();
		if (cooldowns.isCoolingDown(key)) {
			return false;
		}
		if (!world.isClient() && world instanceof ServerWorld serverWorld
				&& player instanceof ServerPlayerEntity serverPlayer) {
			activate(serverWorld, serverPlayer);
		}
		cooldowns.set(key, cooldownTicks);
		return true;
	}

	static void burst(ServerWorld world, ParticleEffect effect, double x, double y, double z) {
		world.spawnParticles(effect, x, y, z, 30, 0.5, 0.8, 0.5, 0.05);
	}

	static List<HostileEntity> hostiles(ServerWorld world, ServerPlayerEntity player, double radius) {
		return world.getEntitiesByClass(HostileEntity.class, player.getBoundingBox().expand(radius), e -> e.isAlive());
	}
}
