package com.infinitygems;

import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.item.Item;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTables;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.util.Identifier;

/** Aggiunge i contenitori e il guanto ai forzieri delle strutture vanilla. */
public final class ModLoot {
	private ModLoot() {
	}

	public static void register() {
		LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
			if (!source.isBuiltin()) {
				return;
			}
			add(tableBuilder, id, LootTables.VILLAGE_WEAPONSMITH_CHEST, ModItems.GAUNTLET, 0.15F);
			add(tableBuilder, id, LootTables.STRONGHOLD_CORRIDOR_CHEST, ModItems.CONTAINERS.get(GemType.SPACE), 0.12F);
			add(tableBuilder, id, LootTables.END_CITY_TREASURE_CHEST, ModItems.CONTAINERS.get(GemType.MIND), 0.20F);
			add(tableBuilder, id, LootTables.NETHER_BRIDGE_CHEST, ModItems.CONTAINERS.get(GemType.REALITY), 0.10F);
			add(tableBuilder, id, LootTables.UNDERWATER_RUIN_BIG_CHEST, ModItems.CONTAINERS.get(GemType.POWER), 0.15F);
			add(tableBuilder, id, LootTables.STRONGHOLD_LIBRARY_CHEST, ModItems.CONTAINERS.get(GemType.TIME), 0.15F);
			add(tableBuilder, id, LootTables.BASTION_TREASURE_CHEST, ModItems.CONTAINERS.get(GemType.SOUL), 0.25F);
		});
	}

	private static void add(LootTable.Builder builder, Identifier tableId, Identifier target, Item item, float chance) {
		if (!tableId.equals(target)) {
			return;
		}
		builder.pool(LootPool.builder()
				.rolls(ConstantLootNumberProvider.create(1.0F))
				.conditionally(RandomChanceLootCondition.builder(chance))
				.with(ItemEntry.builder(item))
				.build());
	}
}
